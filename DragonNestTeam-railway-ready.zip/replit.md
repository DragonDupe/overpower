# Dragon Nest Team Formation App

## Overview

This is a hybrid Discord bot and web application for managing Dragon Nest game team formations. The application features a real Discord bot built with Discord.js that provides `/teamstart` slash commands, interactive button-based role selection, and real-time team management. Players can create and join teams through Discord interactions, with the bot supporting 10 Dragon Nest character roles and 8-player team capacity limits. The system includes both Discord bot functionality and a web interface for administration.

## User Preferences

Preferred communication style: Simple, everyday language.
Bot deployment preference: 24/7 online hosting for continuous Discord server operation.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for client-side routing
- **Build Tool**: Vite for development and production builds
- **Component System**: Radix UI primitives with custom styling

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API endpoints
- **Discord Bot**: Discord.js v14 with slash commands and button interactions
- **Database ORM**: Drizzle ORM with PostgreSQL dialect (with MemStorage fallback)
- **Session Management**: Express sessions with PostgreSQL store
- **Development**: tsx for TypeScript execution in development

### Data Storage
- **Primary Database**: PostgreSQL (configured for Neon serverless)
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Location**: `shared/schema.ts` for shared types between frontend and backend
- **Migrations**: Drizzle Kit for database migrations in `./migrations` directory

## Key Components

### Database Schema
- **Teams Table**: Stores team information (name, status, max members, creation date)
- **Team Members Table**: Stores player memberships with roles and join dates
- **Dragon Nest Roles**: Predefined character classes (Paladin, Priest, Mercenary, etc.)

### API Endpoints
- `GET /api/teams` - Retrieve all teams with their members
- `GET /api/teams/:id` - Get specific team with members
- `POST /api/teams` - Create new team
- `POST /api/teams/:id/join` - Join team with specified role
- `POST /api/teams/:id/leave` - Leave team 
- `POST /api/commands/teamstart` - Discord command to create new team formation

### Frontend Pages
- **Team Formation**: Discord-style interface with:
  - Command `/teamstart` interface for creating new teams
  - Multiple team embeds displaying all active teams
  - Role-based joining with emoji reactions
  - Real-time team status and member management
  - Custom Over Power bot branding with logo
- **Not Found**: 404 error page

### UI Components
- Comprehensive shadcn/ui component library
- Custom role icons and color coding for Dragon Nest classes
- Responsive design with mobile support
- Toast notifications for user feedback

## Data Flow

1. **Client Request**: React components use TanStack Query to make API requests
2. **API Processing**: Express routes handle requests, validate data with Zod schemas
3. **Database Operations**: Drizzle ORM executes type-safe database queries
4. **Response**: JSON data returned to client with error handling
5. **UI Updates**: React Query manages cache updates and UI re-rendering

## External Dependencies

### Discord Integration
- **Discord.js**: Discord bot framework v14
- **Discord REST API**: For slash command registration  
- **Environment**: Requires `DISCORD_BOT_TOKEN` and `DISCORD_CLIENT_ID`
- **Permissions**: Send Messages, Use Slash Commands, Embed Links, Read Message History

### Database
- **Primary**: In-memory storage (MemStorage) for development
- **Optional**: Neon PostgreSQL for production persistence
- **Connection**: Uses `@neondatabase/serverless` driver when configured
- **Environment**: Optional `DATABASE_URL` environment variable

### UI Libraries
- **Radix UI**: Accessible component primitives
- **Lucide React**: Icon library
- **Tailwind CSS**: Utility-first CSS framework
- **Class Variance Authority**: Component variant management

### Development Tools
- **Replit Integration**: Custom Vite plugins for Replit environment
- **TypeScript**: Full type safety across frontend and backend
- **ESBuild**: Production bundling for server code

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR
- **Backend**: tsx with auto-restart on file changes
- **Database**: Drizzle Kit for schema pushing and migrations

### Production
- **Frontend**: Static build output to `dist/public`
- **Backend**: ESBuild bundle to `dist/index.js`
- **Deployment**: Single Node.js process serving both API and static files
- **Database**: PostgreSQL connection via environment variable

### Environment Configuration
- Development and production modes with different optimizations
- Replit-specific plugins and banner integration
- Automatic static file serving in production mode

## Architecture Decisions

### Monorepo Structure
**Problem**: Managing shared types between frontend and backend
**Solution**: Shared schema definitions in `shared/` directory
**Benefits**: Type safety, single source of truth, reduced duplication

### Database Choice
**Problem**: Need for reliable data persistence with TypeScript support
**Solution**: PostgreSQL with Drizzle ORM and Neon serverless hosting
**Benefits**: Strong typing, serverless scaling, familiar SQL interface

### State Management
**Problem**: Server state synchronization and caching
**Solution**: TanStack Query instead of client-side state management
**Benefits**: Automatic caching, background updates, optimistic updates

### Component Library
**Problem**: Consistent UI design with accessibility
**Solution**: shadcn/ui built on Radix UI primitives
**Benefits**: Accessible by default, customizable, modern design system