import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const DRAGON_NEST_ROLES = [
  "Paladin",
  "Priest", 
  "Mercenary",
  "Sword Master",
  "Force User",
  "Elemental Lord",
  "Acrobat",
  "Bow Master",
  "Alchemist",
  "Gear Master"
] as const;

export const ROLE_EMOJIS = {
  "Paladin": "🛡️",
  "Priest": "✨", 
  "Mercenary": "⚔️",
  "Sword Master": "🗡️",
  "Force User": "🔮",
  "Elemental Lord": "🔥",
  "Acrobat": "🤸",
  "Bow Master": "🏹",
  "Alchemist": "🧪",
  "Gear Master": "⚙️"
} as const;

export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  status: text("status").notNull().default("active"), // active, full, disbanded
  maxMembers: integer("max_members").notNull().default(8),
  createdAt: timestamp("created_at").defaultNow(),
});

export const teamMembers = pgTable("team_members", {
  id: serial("id").primaryKey(),
  teamId: integer("team_id").notNull(),
  username: text("username").notNull(),
  role: text("role").notNull(),
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const insertTeamSchema = createInsertSchema(teams).pick({
  name: true,
  maxMembers: true,
});

export const insertTeamMemberSchema = createInsertSchema(teamMembers).pick({
  teamId: true,
  username: true,
  role: true,
});

export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Team = typeof teams.$inferSelect;
export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type TeamMember = typeof teamMembers.$inferSelect;
export type DragonNestRole = typeof DRAGON_NEST_ROLES[number];

export const teamMemberWithDetailsSchema = z.object({
  id: z.number(),
  teamId: z.number(),
  username: z.string(),
  role: z.enum(DRAGON_NEST_ROLES),
  joinedAt: z.date().nullable(),
});

export type TeamMemberWithDetails = z.infer<typeof teamMemberWithDetailsSchema>;

export const teamWithMembersSchema = z.object({
  id: z.number(),
  name: z.string(),
  status: z.string(),
  maxMembers: z.number(),
  createdAt: z.date().nullable(),
  members: z.array(teamMemberWithDetailsSchema),
  availableRoles: z.array(z.enum(DRAGON_NEST_ROLES)),
});

export type TeamWithMembers = z.infer<typeof teamWithMembersSchema>;
