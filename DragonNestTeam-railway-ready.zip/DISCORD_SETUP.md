# Discord Bot Setup Guide

## Bot "Over Power" sudah siap!

### Status Saat Ini
✅ **Bot Code**: Sudah lengkap dengan semua fitur
✅ **Express Server**: Berjalan di port 5000  
✅ **API Routes**: Tersedia untuk web interface
⚠️ **Discord Connection**: Perlu perbaikan token

### Fitur Bot Discord
- **Slash Command**: `/teamstart <nama-tim>` untuk membuat tim baru
- **Interactive Buttons**: Tombol role untuk join/leave tim
- **Real-time Updates**: Embed yang update otomatis
- **Role Management**: 10 role Dragon Nest, maksimal 8 pemain per tim
- **User Mentions**: Bot akan mention Discord users yang join

### 🤖 Bot Siap Diundang!

**Status Bot:** ✅ ONLINE dan siap digunakan

**Link Invite Bot:**
```
https://discord.com/api/oauth2/authorize?client_id=1393067475767132250&permissions=2148537408&scope=bot%20applications.commands
```

**Link Invite Dengan Permissions Minimal:**
```
https://discord.com/api/oauth2/authorize?client_id=1393067475767132250&permissions=274877975552&scope=bot%20applications.commands
```

**Permissions yang dibutuhkan:**
- Send Messages
- Use Slash Commands  
- Embed Links
- Read Message History
- Add Reactions

### ⚠️ MASALAH TOKEN DETECTED

**Status saat ini:** Token tidak valid (format salah)
- Token length: 64 (seharusnya ~70+ karakter)
- Format: Tidak mengandung tanda titik (.)

### Cara Mendapatkan Token yang Benar

1. **Buka Discord Developer Portal**
   - https://discord.com/developers/applications

2. **Buat aplikasi baru atau pilih yang ada**
   - Klik "New Application"
   - Beri nama "Over Power" atau nama lain

3. **Pergi ke tab "Bot"**
   - Klik "Add Bot" (jika belum ada)
   - Di bagian "Token", klik "Reset Token"
   - **PENTING**: Copy token yang baru muncul

4. **Ciri-ciri token yang benar:**
   - Panjang sekitar 70+ karakter
   - Mengandung tanda titik (.) sebagai pemisah
   - Format: `XXXXXXXXX.YYYYYY.ZZZZZZZZZZZZZZZZZZZZZZZZZ`

5. **Update di Replit:**
   - Buka Replit Secrets (ikon kunci di sidebar)
   - Edit `DISCORD_BOT_TOKEN`
   - Paste token yang baru

6. **Enable Bot Permissions:**
   - Scroll ke bawah di tab "Bot"  
   - Centang "MESSAGE CONTENT INTENT" (jika ada)
   - Save changes

### 📝 Cara Menggunakan Bot

1. **Invite bot ke server Discord:**
   - Klik salah satu link invite di atas
   - Pilih server Discord Anda
   - Pastikan bot mendapat permissions yang diperlukan
   - Klik "Authorize"

2. **Buat tim raid baru:**
   ```
   /buatraidtim nama-tim: Tim Dragon Nest
   ```
   
   **Atau dengan channel notifikasi terpisah:**
   ```
   /buatraidtim nama-tim: Tim Dragon Nest channel-notifikasi: #raid-notifications
   ```

3. **Bot akan membuat embed interaktif:**
   - Embed dengan tampilan yang luas dan menarik
   - 10 tombol role Dragon Nest untuk dipilih
   - Progress bar visual
   - Informasi anggota tim real-time

4. **Players bergabung dengan tim:**
   - Klik tombol role yang diinginkan
   - Bot akan update embed secara otomatis
   - Notifikasi join dikirim ke channel yang ditentukan
   - User mendapat konfirmasi pribadi

5. **Keluar dari tim:**
   - Klik tombol "Keluar dari Tim" (🚪)
   - Bot akan update embed dan kirim notifikasi leave

### Web Interface

Selain bot Discord, aplikasi juga memiliki web interface di:
- Development: http://localhost:5000
- Production: URL Replit deployment

Interface web ini berfungsi sebagai backup dan dashboard admin.