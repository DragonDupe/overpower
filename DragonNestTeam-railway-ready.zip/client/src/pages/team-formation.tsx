import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Users, Shield, Sparkles, Swords, Sword, Gem, Flame, PersonStanding, Target, FlaskConical, Settings } from "lucide-react";
import type { TeamWithMembers, DragonNestRole } from "@shared/schema";
import { ROLE_EMOJIS } from "@shared/schema";
import overpowerLogo from "@assets/overpower_1752203175841.png";

const ROLE_ICONS = {
  "Paladin": Shield,
  "Priest": Sparkles,
  "Mercenary": Swords,
  "Sword Master": Sword,
  "Force User": Gem,
  "Elemental Lord": Flame,
  "Acrobat": PersonStanding,
  "Bow Master": Target,
  "Alchemist": FlaskConical,
  "Gear Master": Settings,
};

const ROLE_COLORS = {
  "Paladin": "text-blue-400",
  "Priest": "text-green-400",
  "Mercenary": "text-red-400",
  "Sword Master": "text-blue-300",
  "Force User": "text-yellow-400",
  "Elemental Lord": "text-red-500",
  "Acrobat": "text-green-300",
  "Bow Master": "text-green-500",
  "Alchemist": "text-yellow-500",
  "Gear Master": "text-gray-400",
};

export default function TeamFormation() {
  const [username, setUsername] = useState("");
  const [newTeamName, setNewTeamName] = useState("");
  const [showCreateTeam, setShowCreateTeam] = useState(false);
  const { toast } = useToast();

  const { data: teams, isLoading } = useQuery<TeamWithMembers[]>({
    queryKey: ["/api/teams"],
  });

  const joinTeamMutation = useMutation({
    mutationFn: async ({ teamId, username, role }: { teamId: number; username: string; role: DragonNestRole }) => {
      const response = await apiRequest("POST", `/api/teams/${teamId}/join`, { username, role });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      toast({
        title: "Berhasil bergabung!",
        description: "Kamu telah bergabung dengan tim.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Gagal bergabung",
        description: error.message || "Terjadi kesalahan saat bergabung dengan tim.",
        variant: "destructive",
      });
    },
  });

  const leaveTeamMutation = useMutation({
    mutationFn: async ({ teamId, username }: { teamId: number; username: string }) => {
      const response = await apiRequest("POST", `/api/teams/${teamId}/leave`, { username });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      toast({
        title: "Berhasil keluar",
        description: "Kamu telah keluar dari tim.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Gagal keluar",
        description: error.message || "Terjadi kesalahan saat keluar dari tim.",
        variant: "destructive",
      });
    },
  });

  const createTeamMutation = useMutation({
    mutationFn: async ({ teamName, username }: { teamName: string; username: string }) => {
      const response = await apiRequest("POST", "/api/commands/teamstart", { teamName, username });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      setNewTeamName("");
      setShowCreateTeam(false);
      toast({
        title: "Tim berhasil dibuat!",
        description: data.message || `Tim "${data.team?.name}" telah dibuat.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Gagal membuat tim",
        description: error.message || "Terjadi kesalahan saat membuat tim baru.",
        variant: "destructive",
      });
    },
  });

  const handleJoinTeam = (teamId: number, role: DragonNestRole) => {
    if (!username.trim()) {
      toast({
        title: "Username diperlukan",
        description: "Masukkan username Discord kamu untuk bergabung.",
        variant: "destructive",
      });
      return;
    }

    joinTeamMutation.mutate({ teamId, username: username.trim(), role });
  };

  const handleLeaveTeam = (teamId: number) => {
    if (!username.trim()) {
      toast({
        title: "Username diperlukan",
        description: "Masukkan username Discord kamu untuk keluar.",
        variant: "destructive",
      });
      return;
    }

    leaveTeamMutation.mutate({ teamId, username: username.trim() });
  };

  const handleCreateTeam = () => {
    if (!username.trim()) {
      toast({
        title: "Username diperlukan",
        description: "Masukkan username Discord kamu untuk membuat tim.",
        variant: "destructive",
      });
      return;
    }

    if (!newTeamName.trim()) {
      toast({
        title: "Nama tim diperlukan",
        description: "Masukkan nama tim untuk command /teamstart.",
        variant: "destructive",
      });
      return;
    }

    createTeamMutation.mutate({ teamName: newTeamName.trim(), username: username.trim() });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-discord-darkest text-discord-text flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-discord-blurple mx-auto mb-4"></div>
          <p>Memuat formasi tim...</p>
        </div>
      </div>
    );
  }

  if (!teams || teams.length === 0) {
    return (
      <div className="min-h-screen bg-discord-darkest text-discord-text flex items-center justify-center">
        <div className="text-center">
          <p>Tidak ada tim yang tersedia. Gunakan command /teamstart untuk membuat tim baru.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-discord-darkest">
      {/* Discord Interface */}
      <div className="flex h-screen">
        {/* Left Sidebar */}
        <div className="w-16 bg-discord-darkest flex flex-col items-center py-3 space-y-2">
          <div className="w-12 h-12 rounded-full overflow-hidden flex items-center justify-center bg-black">
            <img 
              src={overpowerLogo} 
              alt="Over Power Bot"
              className="w-12 h-12 object-cover"
            />
          </div>
          <div className="w-8 h-0.5 bg-discord-text-muted rounded"></div>
          <div className="w-12 h-12 bg-discord-darker rounded-full flex items-center justify-center hover:bg-discord-blurple transition-colors cursor-pointer">
            <Users className="w-5 h-5 text-discord-text" />
          </div>
        </div>

        {/* Guild Sidebar */}
        <div className="w-60 bg-discord-darker flex flex-col">
          {/* Guild Header */}
          <div className="h-12 bg-discord-dark shadow-lg flex items-center px-4 border-b border-discord-darkest">
            <h2 className="text-white font-semibold">Dragon Nest Guild</h2>
          </div>
          
          {/* Channel List */}
          <div className="flex-1 p-2">
            <div className="mb-4">
              <div className="flex items-center px-2 py-1 text-discord-text-muted text-xs font-semibold uppercase tracking-wide">
                <span className="mr-1">▼</span>
                Text Channels
              </div>
              <div className="ml-4 space-y-1">
                <div className="flex items-center px-2 py-1 text-discord-text-muted hover:text-discord-text hover:bg-discord-dark rounded cursor-pointer">
                  <span className="mr-2">#</span>
                  general
                </div>
                <div className="flex items-center px-2 py-1 bg-discord-text-muted bg-opacity-20 text-white rounded">
                  <span className="mr-2">#</span>
                  team-formation
                </div>
                <div className="flex items-center px-2 py-1 text-discord-text-muted hover:text-discord-text hover:bg-discord-dark rounded cursor-pointer">
                  <span className="mr-2">#</span>
                  raid-discussion
                </div>
              </div>
            </div>
          </div>

          {/* User Panel */}
          <div className="h-14 bg-discord-darkest flex items-center px-2">
            <div className="flex items-center flex-1">
              <div className="w-8 h-8 bg-discord-blurple rounded-full mr-2 flex items-center justify-center">
                <span className="text-white text-sm font-semibold">U</span>
              </div>
              <div className="flex-1">
                <div className="text-white text-sm font-medium">
                  {username || "YourUsername"}
                </div>
                <div className="text-discord-text-muted text-xs">#1234</div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col bg-discord-dark">
          {/* Channel Header */}
          <div className="h-12 bg-discord-dark shadow-sm flex items-center px-4 border-b border-discord-darkest">
            <span className="text-discord-text-muted mr-2">#</span>
            <h3 className="text-white font-semibold">team-formation</h3>
            <div className="ml-4 text-discord-text-muted text-sm">Formasi tim untuk raid Dragon Nest</div>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* Username Input */}
            <Card className="bg-discord-darker border-discord-darkest">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <label className="text-discord-text text-sm font-medium">Username Discord:</label>
                  <Input
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Masukkan username Discord kamu"
                    className="bg-discord-dark border-discord-darkest text-discord-text"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Command /teamstart Interface */}
            <Card className="bg-discord-darker border-discord-darkest">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-discord-text font-semibold">Command /teamstart</h4>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowCreateTeam(!showCreateTeam)}
                    className="bg-discord-dark border-discord-darkest text-discord-text hover:bg-discord-darkest"
                  >
                    {showCreateTeam ? "Tutup" : "Buat Tim Baru"}
                  </Button>
                </div>
                
                {showCreateTeam && (
                  <div className="space-y-3">
                    <div className="bg-discord-dark rounded p-3">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-discord-text-muted text-sm">Command:</span>
                        <code className="bg-discord-darkest px-2 py-1 rounded text-discord-blurple text-sm">
                          /teamstart
                        </code>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Input
                          value={newTeamName}
                          onChange={(e) => setNewTeamName(e.target.value)}
                          placeholder="Masukkan nama tim (contoh: Raid Harian)"
                          className="bg-discord-darkest border-discord-darkest text-discord-text flex-1"
                        />
                        <Button
                          onClick={handleCreateTeam}
                          disabled={createTeamMutation.isPending || !newTeamName.trim() || !username.trim()}
                          className="bg-discord-blurple hover:bg-blue-600"
                        >
                          {createTeamMutation.isPending ? "Membuat..." : "Buat Tim"}
                        </Button>
                      </div>
                    </div>
                    <div className="text-discord-text-muted text-xs">
                      💡 Command ini akan membuat tim formasi baru dengan kapasitas 8 pemain dari 10 role Dragon Nest yang tersedia.
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Bot Messages with Team Embeds */}
            {teams.map((team) => {
              const progressPercentage = (team.members.length / team.maxMembers) * 100;
              const isTeamFull = team.members.length >= team.maxMembers;
              const currentUserMember = team.members.find(member => member.username === username.trim());

              return (
                <div key={team.id} className="flex items-start space-x-3">
                  <div className="w-10 h-10 rounded-full overflow-hidden flex items-center justify-center bg-black">
                    <img 
                      src={overpowerLogo} 
                      alt="Over Power Bot"
                      className="w-10 h-10 object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="text-white font-medium">Over Power</span>
                      <Badge variant="secondary" className="bg-discord-blurple text-white text-xs">BOT</Badge>
                      <span className="text-discord-text-muted text-xs">Today at {new Date().toLocaleTimeString()}</span>
                    </div>
                    
                    {/* Team Formation Embed */}
                    <div className="mt-2 bg-discord-darker border-l-4 border-discord-yellow rounded p-4 max-w-2xl">
                      {/* Embed Header */}
                      <div className="flex items-center mb-3">
                        <Users className="text-discord-yellow mr-2 w-5 h-5" />
                        <h3 className="text-white font-bold text-lg">{team.name}</h3>
                      </div>
                      
                      {/* Team Status */}
                      <div className="mb-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-discord-text">Status Tim:</span>
                          <Badge className={`${isTeamFull ? 'bg-discord-red' : 'bg-discord-green'} text-white`}>
                            {isTeamFull ? 'Penuh' : 'Aktif'} ({team.members.length}/{team.maxMembers} pemain)
                          </Badge>
                        </div>
                        <div className="w-full bg-discord-darkest rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full transition-all duration-300 ${isTeamFull ? 'bg-discord-red' : 'bg-discord-green'}`}
                            style={{ width: `${progressPercentage}%` }}
                          ></div>
                        </div>
                      </div>

                      {/* Available Roles Grid */}
                      <div className="mb-4">
                        <h4 className="text-discord-text font-semibold mb-2">Role yang Tersedia:</h4>
                        <div className="grid grid-cols-2 gap-2">
                          {Object.entries(ROLE_ICONS).map(([role, IconComponent]) => {
                            const isTaken = team.members.some(member => member.role === role);
                            const canJoin = !isTeamFull && !isTaken && !currentUserMember;
                            
                            return (
                              <div 
                                key={role}
                                className={`bg-discord-dark rounded p-2 flex items-center justify-between ${
                                  canJoin ? 'hover:bg-discord-darkest cursor-pointer transition-colors' : ''
                                }`}
                                onClick={() => canJoin && handleJoinTeam(team.id, role as DragonNestRole)}
                              >
                                <div className="flex items-center">
                                  <IconComponent className={`w-4 h-4 mr-2 ${ROLE_COLORS[role as DragonNestRole]}`} />
                                  <span className="text-discord-text text-sm">{role}</span>
                                </div>
                                <span className={`text-xs px-1 rounded ${
                                  isTaken ? 'bg-discord-green text-white' : 'bg-discord-text-muted text-white'
                                }`}>
                                  {isTaken ? '✓' : '○'}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Current Team Members */}
                      {team.members.length > 0 && (
                        <div className="mb-4">
                          <h4 className="text-discord-text font-semibold mb-2">Anggota Tim Saat Ini:</h4>
                          <div className="space-y-1">
                            {team.members.map((member) => {
                              const IconComponent = ROLE_ICONS[member.role as DragonNestRole];
                              const isCurrentUser = member.username === username.trim();
                              
                              return (
                                <div key={member.id} className={`flex items-center bg-discord-dark rounded p-2 ${
                                  isCurrentUser ? 'ring-1 ring-discord-blurple' : ''
                                }`}>
                                  <IconComponent className={`w-4 h-4 mr-2 ${ROLE_COLORS[member.role as DragonNestRole]}`} />
                                  <span className="text-discord-text text-sm mr-2">{member.role}:</span>
                                  <span className="text-white font-medium">@{member.username}</span>
                                  {isCurrentUser && (
                                    <Button
                                      size="sm"
                                      variant="destructive"
                                      onClick={() => handleLeaveTeam(team.id)}
                                      className="ml-auto bg-discord-red hover:bg-red-600"
                                      disabled={leaveTeamMutation.isPending}
                                    >
                                      Keluar
                                    </Button>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Instructions */}
                      <div className="bg-discord-blurple bg-opacity-20 rounded p-3 mb-3">
                        <div className="flex items-start">
                          <div className="text-discord-blurple mr-2 mt-0.5">ℹ️</div>
                          <div className="text-discord-text text-sm">
                            <strong>Cara bergabung:</strong> Masukkan username Discord kamu di atas, lalu klik role yang ingin kamu mainkan. Tim maksimal 8 orang dari 10 role yang tersedia.
                          </div>
                        </div>
                      </div>

                      {/* Footer */}
                      <div className="flex items-center justify-between text-xs text-discord-text-muted">
                        <span>Over Power Bot</span>
                        <span>Today at {new Date().toLocaleTimeString()}</span>
                      </div>
                    </div>

                    {/* Reactions */}
                    <div className="mt-2 flex flex-wrap gap-1">
                      {Object.entries(ROLE_EMOJIS).map(([role, emoji]) => {
                        const memberCount = team.members.filter(member => member.role === role).length;
                        const canReact = !isTeamFull && memberCount === 0 && !currentUserMember;
                        
                        return (
                          <button
                            key={role}
                            className={`bg-discord-darker hover:bg-discord-dark border border-discord-darkest rounded px-2 py-1 flex items-center space-x-1 transition-colors ${
                              !canReact ? 'opacity-50 cursor-not-allowed' : ''
                            }`}
                            onClick={() => canReact && handleJoinTeam(team.id, role as DragonNestRole)}
                            disabled={!canReact || joinTeamMutation.isPending}
                          >
                            <span>{emoji}</span>
                            <span className="text-discord-text text-sm">{memberCount}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Message Input */}
          <div className="p-4">
            <div className="bg-discord-text-muted bg-opacity-10 rounded-lg p-3">
              <input 
                type="text" 
                placeholder="Kirim pesan di #team-formation" 
                className="w-full bg-transparent text-discord-text placeholder-discord-text-muted focus:outline-none"
                disabled
              />
            </div>
          </div>
        </div>

        {/* Member List */}
        <div className="w-60 bg-discord-darker">
          {/* Online Members Header */}
          <div className="p-4 border-b border-discord-darkest">
            <h3 className="text-discord-text-muted text-xs font-semibold uppercase tracking-wide">
              Online — {teams.reduce((total, team) => total + team.members.length, 0) + 3}
            </h3>
          </div>
          
          {/* Members List */}
          <div className="p-2 space-y-1">
            <div className="flex items-center px-2 py-1 hover:bg-discord-dark rounded cursor-pointer">
              <div className="relative">
                <div className="w-8 h-8 bg-discord-green rounded-full mr-3 flex items-center justify-center text-white text-sm font-semibold">
                  G
                </div>
                <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-discord-green rounded-full border-2 border-discord-darker"></div>
              </div>
              <span className="text-discord-text text-sm">GuildMaster</span>
            </div>
            
            {teams.flatMap(team => team.members).map((member) => (
              <div key={member.id} className="flex items-center px-2 py-1 hover:bg-discord-dark rounded cursor-pointer">
                <div className="relative">
                  <div className="w-8 h-8 bg-discord-blurple rounded-full mr-3 flex items-center justify-center text-white text-sm font-semibold">
                    {member.username[0].toUpperCase()}
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-discord-green rounded-full border-2 border-discord-darker"></div>
                </div>
                <span className="text-discord-text text-sm">{member.username}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
