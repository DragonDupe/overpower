import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTeamSchema, insertTeamMemberSchema, DRAGON_NEST_ROLES } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all teams with members
  app.get("/api/teams", async (req, res) => {
    try {
      const teams = await storage.getAllTeams();
      res.json(teams);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch teams" });
    }
  });

  // Get specific team with members
  app.get("/api/teams/:id", async (req, res) => {
    try {
      const teamId = parseInt(req.params.id);
      if (isNaN(teamId)) {
        return res.status(400).json({ error: "Invalid team ID" });
      }

      const team = await storage.getTeamWithMembers(teamId);
      if (!team) {
        return res.status(404).json({ error: "Team not found" });
      }

      res.json(team);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch team" });
    }
  });

  // Create new team
  app.post("/api/teams", async (req, res) => {
    try {
      const validatedData = insertTeamSchema.parse(req.body);
      const team = await storage.createTeam(validatedData);
      res.status(201).json(team);
    } catch (error) {
      res.status(400).json({ error: "Invalid team data" });
    }
  });

  // Join team with role
  app.post("/api/teams/:id/join", async (req, res) => {
    try {
      const teamId = parseInt(req.params.id);
      if (isNaN(teamId)) {
        return res.status(400).json({ error: "Invalid team ID" });
      }

      const { username, role } = req.body;

      if (!username || typeof username !== "string") {
        return res.status(400).json({ error: "Username is required" });
      }

      if (!role || !DRAGON_NEST_ROLES.includes(role)) {
        return res.status(400).json({ error: "Valid role is required" });
      }

      // Check if team exists
      const team = await storage.getTeamWithMembers(teamId);
      if (!team) {
        return res.status(404).json({ error: "Team not found" });
      }

      // Check if team is full
      if (team.members.length >= team.maxMembers) {
        return res.status(400).json({ error: "Tim sudah penuh! Maksimal 8 pemain." });
      }

      // Check if user is already in team
      const existingMember = await storage.getTeamMember(teamId, username);
      if (existingMember) {
        return res.status(400).json({ error: "Kamu sudah bergabung dengan tim ini!" });
      }

      // Check if role is already taken
      const roleExists = team.members.some(member => member.role === role);
      if (roleExists) {
        return res.status(400).json({ error: `Role ${role} sudah diambil oleh pemain lain!` });
      }

      const memberData = {
        teamId,
        username,
        role,
      };

      const validatedMemberData = insertTeamMemberSchema.parse(memberData);
      const member = await storage.addTeamMember(validatedMemberData);
      
      // Return updated team
      const updatedTeam = await storage.getTeamWithMembers(teamId);
      res.status(201).json(updatedTeam);
    } catch (error) {
      res.status(400).json({ error: "Failed to join team" });
    }
  });

  // Leave team
  app.post("/api/teams/:id/leave", async (req, res) => {
    try {
      const teamId = parseInt(req.params.id);
      if (isNaN(teamId)) {
        return res.status(400).json({ error: "Invalid team ID" });
      }

      const { username } = req.body;

      if (!username || typeof username !== "string") {
        return res.status(400).json({ error: "Username is required" });
      }

      const success = await storage.removeTeamMember(teamId, username);
      if (!success) {
        return res.status(404).json({ error: "Kamu tidak terdaftar dalam tim ini!" });
      }

      // Return updated team
      const updatedTeam = await storage.getTeamWithMembers(teamId);
      res.json(updatedTeam);
    } catch (error) {
      res.status(400).json({ error: "Failed to leave team" });
    }
  });

  // Command /teamstart - Create new team formation
  app.post("/api/commands/teamstart", async (req, res) => {
    try {
      const { teamName, username } = req.body;

      // Validate input
      if (!teamName || typeof teamName !== "string" || teamName.trim().length === 0) {
        return res.status(400).json({ 
          error: "Nama tim diperlukan untuk command /teamstart",
          usage: "Gunakan: /teamstart <nama_tim>"
        });
      }

      if (!username || typeof username !== "string") {
        return res.status(400).json({ error: "Username diperlukan" });
      }

      // Create new team
      const teamData = {
        name: teamName.trim(),
        maxMembers: 8
      };

      const validatedData = insertTeamSchema.parse(teamData);
      const newTeam = await storage.createTeam(validatedData);

      // Get team with members (empty at start)
      const teamWithMembers = await storage.getTeamWithMembers(newTeam.id);

      res.status(201).json({
        success: true,
        message: `Tim "${teamName}" berhasil dibuat! Gunakan reaksi emoji untuk bergabung.`,
        team: teamWithMembers,
        embed: {
          title: `🎮 ${teamName}`,
          description: "Tim formasi baru telah dibuat! Klik role yang tersedia untuk bergabung.",
          color: 0x5865F2, // Discord blurple
          fields: [
            {
              name: "Status Tim",
              value: `Aktif (0/8 pemain)`,
              inline: true
            },
            {
              name: "Dibuat oleh",
              value: `@${username}`,
              inline: true
            }
          ],
          footer: {
            text: "Over Power Bot • Dragon Nest Team Formation"
          },
          timestamp: new Date().toISOString()
        }
      });
    } catch (error) {
      console.error("Error in /teamstart command:", error);
      res.status(400).json({ 
        error: "Gagal membuat tim baru",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
