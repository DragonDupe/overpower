import { Client, GatewayIntentBits, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } from 'discord.js';
import { REST } from '@discordjs/rest';
import { Routes } from 'discord-api-types/v10';
import { storage } from './storage';
import { DRAGON_NEST_ROLES, ROLE_EMOJIS, type DragonNestRole } from '@shared/schema';

export class DiscordBot {
  private client: Client;
  private rest: REST;
  private token: string;
  private clientId: string;

  constructor() {
    this.token = process.env.DISCORD_BOT_TOKEN || '';
    this.clientId = process.env.DISCORD_CLIENT_ID || '';
    
    console.log('🔍 Discord Bot Debug Info:');
    console.log('   Token exists:', !!this.token);
    console.log('   Token length:', this.token.length);
    console.log('   Client ID exists:', !!this.clientId);
    console.log('   Client ID:', this.clientId);
    
    if (!this.token || !this.clientId) {
      console.log('⚠️  Discord bot tokens not found. Bot will not start.');
      console.log('   Set DISCORD_BOT_TOKEN and DISCORD_CLIENT_ID environment variables');
      return;
    }
    
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
      ],
    });

    this.rest = new REST({ version: '10' }).setToken(this.token);
    this.setupEventHandlers();
  }

  private async setupEventHandlers() {
    this.client.once('ready', () => {
      console.log(`🤖 Over Power bot is online! Logged in as ${this.client.user?.tag}`);
      console.log(`📊 Bot status: ${this.client.user?.presence?.status || 'online'}`);
      console.log(`🌐 Connected to ${this.client.guilds.cache.size} servers`);
      
      // Set bot status to online explicitly
      this.client.user?.setStatus('online');
      this.client.user?.setActivity('Dragon Nest Team Formation', { type: 0 }); // Playing activity
      
      // Log server details
      this.client.guilds.cache.forEach(guild => {
        console.log(`📍 Server: ${guild.name} (${guild.id}) - ${guild.memberCount} members`);
      });
      
      this.registerCommands();
    });

    this.client.on('interactionCreate', async (interaction) => {
      if (interaction.isChatInputCommand()) {
        await this.handleSlashCommand(interaction);
      } else if (interaction.isButton()) {
        await this.handleButtonInteraction(interaction);
      }
    });

    // Add error handling for disconnect events
    this.client.on('disconnect', () => {
      console.log('⚠️ Bot disconnected from Discord');
    });

    this.client.on('reconnecting', () => {
      console.log('🔄 Bot reconnecting to Discord...');
    });

    this.client.on('error', (error) => {
      console.error('❌ Discord client error:', error);
    });
  }

  private async registerCommands() {
    const commands = [
      new SlashCommandBuilder()
        .setName('buatraidtim')
        .setDescription('Buat tim formasi baru untuk Dragon Nest raid')
        .addStringOption(option =>
          option
            .setName('nama-tim')
            .setDescription('Nama tim yang akan dibuat')
            .setRequired(true)
        )
        .addStringOption(option =>
          option
            .setName('waktu-raid')
            .setDescription('Waktu mulai raid (contoh: 20:00, besok 19:30, atau Minggu 21:00)')
            .setRequired(false)
        )
        .addChannelOption(option =>
          option
            .setName('channel-notifikasi')
            .setDescription('Channel untuk notifikasi join/leave (opsional)')
            .setRequired(false)
        ),
    ];

    try {
      console.log('🔄 Registering Discord slash commands...');
      await this.rest.put(
        Routes.applicationCommands(this.clientId),
        { body: commands.map(command => command.toJSON()) }
      );
      console.log('✅ Discord slash commands registered successfully!');
    } catch (error) {
      console.error('❌ Error registering commands:', error);
    }
  }

  private async handleSlashCommand(interaction: any) {
    if (interaction.commandName === 'buatraidtim') {
      const teamName = interaction.options.getString('nama-tim');
      const raidTime = interaction.options.getString('waktu-raid');
      const notificationChannel = interaction.options.getChannel('channel-notifikasi');

      try {
        // Validate required data
        if (!interaction.user || !interaction.channel) {
          await interaction.reply({
            content: '❌ Error: User atau channel information tidak tersedia.',
            flags: 64,
          });
          return;
        }

        // Create new team
        const team = await storage.createTeam({
          name: teamName,
          maxMembers: 8
        });

        // Store notification channel ID if provided
        const channelId = notificationChannel ? notificationChannel.id : interaction.channel.id;
        
        const embed = await this.createTeamEmbed(team.id, channelId, raidTime);
        const buttons = this.createRoleButtons(team.id, channelId);

        let responseContent = `🎮 **Tim "${teamName}" berhasil dibuat!**`;
        if (raidTime) {
          responseContent += `\n⏰ **Waktu Raid:** ${raidTime}`;
        }
        if (notificationChannel) {
          responseContent += `\n📢 Notifikasi akan dikirim ke <#${channelId}>`;
        }

        await interaction.reply({
          content: responseContent,
          embeds: [embed],
          components: buttons,
        });

      } catch (error) {
        console.error('Error creating team:', error);
        await interaction.reply({
          content: '❌ Gagal membuat tim. Silakan coba lagi.',
          flags: 64,
        });
      }
    }
  }

  private async handleButtonInteraction(interaction: any) {
    const parts = interaction.customId.split('_');
    const action = parts[0];
    const teamId = parseInt(parts[1]);
    
    if (action === 'join') {
      const role = parts[2] as DragonNestRole;
      const channelId = parts[3];
      await this.handleJoinTeam(interaction, teamId, role, channelId);
    } else if (action === 'leave') {
      const channelId = parts[2];
      await this.handleLeaveTeam(interaction, teamId, channelId);
    }
  }

  private async handleJoinTeam(interaction: any, teamId: number, role: DragonNestRole, notificationChannelId?: string) {
    // Validate user exists
    if (!interaction.user) {
      await interaction.reply({
        content: '❌ Error: User information tidak tersedia.',
        flags: 64,
      });
      return;
    }
    
    const userId = interaction.user.id;
    
    try {
      // Check if team exists and get current state
      const team = await storage.getTeamWithMembers(teamId);
      if (!team) {
        await interaction.reply({
          content: '❌ Tim tidak ditemukan.',
          flags: 64,
        });
        return;
      }

      // Check if team is full
      if (team.members.length >= team.maxMembers) {
        await interaction.reply({
          content: '❌ Tim sudah penuh! Maksimal 8 pemain.',
          flags: 64,
        });
        return;
      }

      // Check if user is already in team (by userId)
      const existingMember = team.members.find(member => member.username === userId);
      if (existingMember) {
        await interaction.reply({
          content: '❌ Kamu sudah bergabung dengan tim ini!',
          flags: 64,
        });
        return;
      }

      // Check if role is already taken
      const roleExists = team.members.some(member => member.role === role);
      if (roleExists) {
        await interaction.reply({
          content: `❌ Role ${role} sudah diambil oleh pemain lain!`,
          flags: 64,
        });
        return;
      }

      // Add member to team
      await storage.addTeamMember({
        teamId,
        username: userId,
        role,
      });

      // Update embed with new team state
      const updatedEmbed = await this.createTeamEmbed(teamId, notificationChannelId);
      const updatedButtons = this.createRoleButtons(teamId, notificationChannelId);

      await interaction.update({
        embeds: [updatedEmbed],
        components: updatedButtons,
      });

      // Send notification to specified channel or current channel
      try {
        const targetChannelId = notificationChannelId || interaction.channel.id;
        const targetChannel = await this.client.channels.fetch(targetChannelId);
        
        if (targetChannel && targetChannel.isTextBased()) {
          await targetChannel.send({
            content: `✅ <@${userId}> bergabung ke **${team.name}** sebagai **${role}** ${ROLE_EMOJIS[role]}`,
          });
        }
      } catch (channelError) {
        console.warn('⚠️ Could not send notification to channel:', channelError);
        // Fallback to current channel
        try {
          await interaction.channel.send({
            content: `✅ <@${userId}> bergabung ke **${team.name}** sebagai **${role}** ${ROLE_EMOJIS[role]}`,
          });
        } catch (fallbackError) {
          console.warn('⚠️ Could not send fallback notification:', fallbackError);
        }
      }

      // Send ephemeral confirmation to user
      await interaction.followUp({
        content: `✅ Berhasil bergabung sebagai **${role}**!`,
        flags: 64,
      });

    } catch (error) {
      console.error('Error joining team:', error);
      await interaction.reply({
        content: '❌ Gagal bergabung dengan tim. Silakan coba lagi.',
        flags: 64,
      });
    }
  }

  private async handleLeaveTeam(interaction: any, teamId: number, notificationChannelId?: string) {
    // Validate user exists
    if (!interaction.user) {
      await interaction.reply({
        content: '❌ Error: User information tidak tersedia.',
        flags: 64,
      });
      return;
    }
    
    const userId = interaction.user.id;
    
    try {
      // Get team info before removal
      const team = await storage.getTeamWithMembers(teamId);
      if (!team) {
        await interaction.reply({
          content: '❌ Tim tidak ditemukan.',
          flags: 64,
        });
        return;
      }

      const memberToRemove = team.members.find(member => member.username === userId);
      if (!memberToRemove) {
        await interaction.reply({
          content: '❌ Kamu tidak terdaftar dalam tim ini!',
          flags: 64,
        });
        return;
      }

      const success = await storage.removeTeamMember(teamId, userId);
      if (!success) {
        await interaction.reply({
          content: '❌ Gagal keluar dari tim!',
          flags: 64,
        });
        return;
      }

      // Update embed with new team state
      const updatedEmbed = await this.createTeamEmbed(teamId, notificationChannelId);
      const updatedButtons = this.createRoleButtons(teamId, notificationChannelId);

      await interaction.update({
        embeds: [updatedEmbed],
        components: updatedButtons,
      });

      // Send notification to specified channel or current channel
      try {
        const targetChannelId = notificationChannelId || interaction.channel.id;
        const targetChannel = await this.client.channels.fetch(targetChannelId);
        
        if (targetChannel && targetChannel.isTextBased()) {
          await targetChannel.send({
            content: `👋 <@${userId}> keluar dari **${team.name}** (${memberToRemove.role})`,
          });
        }
      } catch (channelError) {
        console.warn('⚠️ Could not send leave notification to channel:', channelError);
        // Fallback to current channel
        try {
          await interaction.channel.send({
            content: `👋 <@${userId}> keluar dari **${team.name}** (${memberToRemove.role})`,
          });
        } catch (fallbackError) {
          console.warn('⚠️ Could not send fallback leave notification:', fallbackError);
        }
      }

      // Send ephemeral confirmation to user
      await interaction.followUp({
        content: `✅ Berhasil keluar dari tim!`,
        flags: 64,
      });

    } catch (error) {
      console.error('Error leaving team:', error);
      await interaction.reply({
        content: '❌ Gagal keluar dari tim. Silakan coba lagi.',
        flags: 64,
      });
    }
  }

  private async createTeamEmbed(teamId: number, notificationChannelId?: string, raidTime?: string) {
    const team = await storage.getTeamWithMembers(teamId);
    if (!team) throw new Error('Team not found');

    const isTeamFull = team.members.length >= team.maxMembers;
    const progressPercentage = Math.round((team.members.length / team.maxMembers) * 100);
    const progressBar = '█'.repeat(Math.floor(progressPercentage / 10)) + '░'.repeat(10 - Math.floor(progressPercentage / 10));

    const embed = new EmbedBuilder()
      .setTitle(`🏰 ${team.name}`)
      .setDescription(`**Tim Formasi Dragon Nest Raid**\n\n💫 Klik tombol role di bawah untuk bergabung dengan tim!\n🔔 ${notificationChannelId ? `Notifikasi akan dikirim ke <#${notificationChannelId}>` : 'Notifikasi di channel ini'}`)
      .setColor(isTeamFull ? 0xED4245 : 0x00D4AA)
      .setThumbnail('https://cdn.discordapp.com/attachments/123456789/overpower-logo.png')
      .addFields(
        {
          name: '📊 Status Tim',
          value: `${isTeamFull ? '🔴 **TIM PENUH**' : '🟢 **SEDANG MEREKRUT**'}\n👥 ${team.members.length}/${team.maxMembers} Pemain`,
          inline: true
        },
        {
          name: '📈 Progress Rekrutmen',
          value: `${progressBar}\n**${progressPercentage}%** Terisi`,
          inline: true
        },
        {
          name: raidTime ? '🕐 Waktu Raid' : '⏰ Dibuat',
          value: raidTime ? `**${raidTime}**` : `<t:${Math.floor(new Date(team.createdAt).getTime() / 1000)}:R>`,
          inline: true
        }
      );

    // Add timestamp if raid time is provided
    if (raidTime) {
      embed.addFields({
        name: '📅 Tim Dibuat',
        value: `<t:${Math.floor(new Date(team.createdAt).getTime() / 1000)}:R>`,
        inline: true
      });
    }

    // Add team members field with better formatting
    if (team.members.length > 0) {
      const membersList = team.members
        .map((member, index) => {
          const roleEmoji = ROLE_EMOJIS[member.role as DragonNestRole];
          return `\`${(index + 1).toString().padStart(2, '0')}\` ${roleEmoji} **${member.role}** • <@${member.username}>`;
        })
        .join('\n');
      
      embed.addFields({
        name: `👥 Anggota Tim (${team.members.length}/${team.maxMembers})`,
        value: membersList,
        inline: false
      });
    }

    // Add available roles with better visual formatting
    const availableRoles = DRAGON_NEST_ROLES
      .filter(role => !team.members.some(member => member.role === role));

    if (availableRoles.length > 0) {
      const availableRolesList = availableRoles
        .map(role => `${ROLE_EMOJIS[role]} **${role}**`)
        .join('  •  ');
      
      embed.addFields({
        name: `🎯 Role Tersedia (${availableRoles.length} slot kosong)`,
        value: availableRolesList,
        inline: false
      });
    }

    embed.setFooter({
      text: 'Over Power Bot • Dragon Nest Team Formation System',
      iconURL: 'https://cdn.discordapp.com/app-icons/1393067475767132250/icon.png'
    });

    return embed;
  }

  private createRoleButtons(teamId: number, notificationChannelId?: string) {
    const rows: ActionRowBuilder<ButtonBuilder>[] = [];
    let currentRow = new ActionRowBuilder<ButtonBuilder>();
    let buttonCount = 0;
    const channelId = notificationChannelId || 'current';

    // Create role buttons (max 5 per row)
    for (const role of DRAGON_NEST_ROLES) {
      if (buttonCount === 5) {
        rows.push(currentRow);
        currentRow = new ActionRowBuilder<ButtonBuilder>();
        buttonCount = 0;
      }

      const button = new ButtonBuilder()
        .setCustomId(`join_${teamId}_${role}_${channelId}`)
        .setLabel(role)
        .setEmoji(ROLE_EMOJIS[role])
        .setStyle(ButtonStyle.Secondary);

      currentRow.addComponents(button);
      buttonCount++;
    }

    // Add current row if it has buttons
    if (buttonCount > 0) {
      rows.push(currentRow);
    }

    // Add leave button in separate row with better styling
    const leaveRow = new ActionRowBuilder<ButtonBuilder>()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`leave_${teamId}_${channelId}`)
          .setLabel('Keluar dari Tim')
          .setEmoji('🚪')
          .setStyle(ButtonStyle.Danger)
      );

    rows.push(leaveRow);

    return rows;
  }

  public async start() {
    if (!this.token) {
      console.log('❌ Discord bot cannot start without DISCORD_BOT_TOKEN');
      return;
    }

    try {
      console.log('🔄 Attempting to connect Discord bot...');
      await this.client.login(this.token);
    } catch (error: any) {
      console.error('❌ Failed to start Discord bot:', error);
      
      if (error.code === 'TokenInvalid') {
        console.log('\n📋 Token troubleshooting steps:');
        console.log('1. Go to https://discord.com/developers/applications');
        console.log('2. Select your application');
        console.log('3. Go to Bot section');
        console.log('4. Click "Reset Token" and copy the new token');
        console.log('5. Make sure bot has necessary permissions');
        console.log('6. Update DISCORD_BOT_TOKEN in Replit Secrets\n');
      }
      
      console.log('🌐 Bot will continue as web interface while Discord connection is being fixed...');
    }
  }

  public getClient() {
    return this.client;
  }
}