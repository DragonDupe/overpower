import { teams, teamMembers, type Team, type InsertTeam, type TeamMember, type InsertTeamMember, type TeamWithMembers, type DragonNestRole, DRAGON_NEST_ROLES } from "@shared/schema";

export interface IStorage {
  // Team operations
  getTeam(id: number): Promise<Team | undefined>;
  getTeamWithMembers(id: number): Promise<TeamWithMembers | undefined>;
  createTeam(team: InsertTeam): Promise<Team>;
  updateTeamStatus(id: number, status: string): Promise<Team | undefined>;
  getAllTeams(): Promise<TeamWithMembers[]>;
  
  // Team member operations
  getTeamMember(teamId: number, username: string): Promise<TeamMember | undefined>;
  addTeamMember(member: InsertTeamMember): Promise<TeamMember>;
  removeTeamMember(teamId: number, username: string): Promise<boolean>;
  getTeamMembers(teamId: number): Promise<TeamMember[]>;
}

export class MemStorage implements IStorage {
  private teams: Map<number, Team>;
  private teamMembers: Map<number, TeamMember>;
  private currentTeamId: number;
  private currentMemberId: number;

  constructor() {
    this.teams = new Map();
    this.teamMembers = new Map();
    this.currentTeamId = 1;
    this.currentMemberId = 1;
    
    // Create default team
    this.createDefaultTeam();
  }

  private async createDefaultTeam() {
    const defaultTeam: Team = {
      id: 1,
      name: "Formasi Tim Raid",
      status: "active",
      maxMembers: 8,
      createdAt: new Date(),
    };
    this.teams.set(1, defaultTeam);
    this.currentTeamId = 2;
  }

  async getTeam(id: number): Promise<Team | undefined> {
    return this.teams.get(id);
  }

  async getTeamWithMembers(id: number): Promise<TeamWithMembers | undefined> {
    const team = this.teams.get(id);
    if (!team) return undefined;

    const members = Array.from(this.teamMembers.values())
      .filter(member => member.teamId === id)
      .map(member => ({
        id: member.id,
        teamId: member.teamId,
        username: member.username,
        role: member.role as DragonNestRole,
        joinedAt: member.joinedAt,
      }));

    const takenRoles = members.map(member => member.role);
    const availableRoles = DRAGON_NEST_ROLES.filter(role => !takenRoles.includes(role));

    return {
      id: team.id,
      name: team.name,
      status: team.status,
      maxMembers: team.maxMembers,
      createdAt: team.createdAt,
      members,
      availableRoles,
    };
  }

  async createTeam(insertTeam: InsertTeam): Promise<Team> {
    const id = this.currentTeamId++;
    const team: Team = {
      id,
      name: insertTeam.name,
      status: "active",
      maxMembers: insertTeam.maxMembers || 8,
      createdAt: new Date(),
    };
    this.teams.set(id, team);
    return team;
  }

  async updateTeamStatus(id: number, status: string): Promise<Team | undefined> {
    const team = this.teams.get(id);
    if (!team) return undefined;

    const updatedTeam = { ...team, status };
    this.teams.set(id, updatedTeam);
    return updatedTeam;
  }

  async getAllTeams(): Promise<TeamWithMembers[]> {
    const allTeams: TeamWithMembers[] = [];
    
    for (const team of Array.from(this.teams.values())) {
      const teamWithMembers = await this.getTeamWithMembers(team.id);
      if (teamWithMembers) {
        allTeams.push(teamWithMembers);
      }
    }
    
    return allTeams;
  }

  async getTeamMember(teamId: number, username: string): Promise<TeamMember | undefined> {
    return Array.from(this.teamMembers.values())
      .find(member => member.teamId === teamId && member.username === username);
  }

  async addTeamMember(insertMember: InsertTeamMember): Promise<TeamMember> {
    const id = this.currentMemberId++;
    const member: TeamMember = {
      ...insertMember,
      id,
      joinedAt: new Date(),
    };
    this.teamMembers.set(id, member);

    // Check if team is now full and update status
    const teamMembers = await this.getTeamMembers(insertMember.teamId);
    const team = await this.getTeam(insertMember.teamId);
    if (team && teamMembers.length >= team.maxMembers) {
      await this.updateTeamStatus(insertMember.teamId, "full");
    }

    return member;
  }

  async removeTeamMember(teamId: number, username: string): Promise<boolean> {
    const member = await this.getTeamMember(teamId, username);
    if (!member) return false;

    this.teamMembers.delete(member.id);

    // Check if team status should be updated back to active
    const team = await this.getTeam(teamId);
    const remainingMembers = await this.getTeamMembers(teamId);
    if (team && team.status === "full" && remainingMembers.length < team.maxMembers) {
      await this.updateTeamStatus(teamId, "active");
    }

    return true;
  }

  async getTeamMembers(teamId: number): Promise<TeamMember[]> {
    return Array.from(this.teamMembers.values())
      .filter(member => member.teamId === teamId);
  }
}

export const storage = new MemStorage();
